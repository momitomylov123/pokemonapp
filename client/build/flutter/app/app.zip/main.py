import flet as ft
import httpx
import os
import tkinter as tk
from tkinter import filedialog

SERVER_URL = "http://192.168.20.228:8000"  # ← cambiá a tu IP si usás celular

# ── Selector de archivo ───────────────────────────────────────────────────────
def seleccionar_archivo():
    root = tk.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    ruta = filedialog.askopenfilename(
        title="🎨 Elegí tu dibujo de Pokémon",
        filetypes=[("Imágenes", "*.jpg *.jpeg *.png *.bmp")]
    )
    root.destroy()
    return ruta if ruta else None

# ── App principal ─────────────────────────────────────────────────────────────
async def main(page: ft.Page):
    page.title = "🎨 PokéDraw"
    page.theme_mode = "light"
    page.padding = 20
    page.horizontal_alignment = "center"
    page.window_width  = 460
    page.window_height = 820
    page.bgcolor = "#E8EAF6"
    page.scroll = "auto"

    # ── Preview imagen seleccionada ───────────────────────────────────────────
    img_preview = ft.Image(src=None, width=260, height=260, fit="contain", visible=False)
    img_container = ft.Container(
        content=img_preview,
        width=280, height=280,
        bgcolor="#FFFFFF",
        border_radius=16,
        border=ft.Border.all(2, "#9FA8DA"),
        visible=False,
    )

    result_card = ft.Container(visible=False)
    status = ft.Text(
        "👉 Seleccioná un dibujo para empezar",
        color="#5C6BC0", size=13, italic=True, text_align="center"
    )

    deck_area = ft.Column(
        visible=False, scroll="auto", height=420,
        spacing=14, horizontal_alignment="center",
    )

    # ── Construir carta de resultado ──────────────────────────────────────────
    def build_result_card(data: dict):
        rarity  = data.get("rarity", {})
        label   = rarity.get("label",  "⚪ COMÚN")
        color   = rarity.get("color",  "#757575")
        stars   = rarity.get("stars",  "★☆☆☆☆")
        action  = data.get("action", "guardada")
        action_msg = "🔄 ¡Carta actualizada!" if action == "actualizada" else "✅ ¡Carta nueva!"

        return ft.Container(
            content=ft.Column([
                ft.Text(action_msg, size=12, color="#5C6BC0", text_align="center", italic=True),
                ft.Text(
                    f"✨ {data['pokemon'].upper()}",
                    weight="bold", size=22, color="#1A237E", text_align="center"
                ),
                ft.Container(
                    content=ft.Text(label, size=12, weight="bold", color="#FFFFFF"),
                    bgcolor=color,
                    padding=ft.Padding.symmetric(horizontal=14, vertical=5),
                    border_radius=20,
                ),
                ft.Text(stars, size=18, color=color, text_align="center"),
                ft.Row([
                    ft.Container(
                        content=ft.Column([
                            ft.Text("❤️ HP",  size=11, color="#9E9E9E"),
                            ft.Text(str(data['hp']), weight="bold", size=20, color="#C62828"),
                        ], horizontal_alignment="center"),
                        padding=12, bgcolor="#FFEBEE", border_radius=10, width=110,
                    ),
                    ft.Container(
                        content=ft.Column([
                            ft.Text("⚔️ ATK", size=11, color="#9E9E9E"),
                            ft.Text(str(data['attack']), weight="bold", size=20, color="#E65100"),
                        ], horizontal_alignment="center"),
                        padding=12, bgcolor="#FFF3E0", border_radius=10, width=110,
                    ),
                ], alignment="center", spacing=12),
                ft.Text(
                    f"🎯 Similitud: {data['similarity']*100:.1f}%",
                    size=11, color="#6A1B9A", text_align="center"
                ),
            ],
            spacing=8, horizontal_alignment="center"),
            padding=18,
            bgcolor="#FFFFFF",
            border_radius=18,
            border=ft.Border.all(3, color),
            width=320,
        )

    # ── Construir carta del mazo ──────────────────────────────────────────────
    def build_deck_card(card: dict, index: int, total: int):
        rarity = card.get("rarity", {})
        label  = rarity.get("label",  "⚪ COMÚN")
        color  = rarity.get("color",  "#757575")
        stars  = rarity.get("stars",  "★☆☆☆☆")
        img_fn = card.get("image", "")
        img_url = f"{SERVER_URL}/images/{img_fn}" if img_fn else None

        img_widget = ft.Image(
            src=img_url,
            width=80, height=80,
            fit="contain",
            visible=bool(img_url),
        ) if img_url else ft.Text("🎨", size=40, text_align="center")

        return ft.Card(
            elevation=5,
            content=ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Text(f"#{total - index}", size=10, color="#9E9E9E"),
                        ft.Container(
                            content=ft.Text(label, size=10, weight="bold", color="#FFFFFF"),
                            bgcolor=color,
                            padding=ft.Padding.symmetric(horizontal=10, vertical=3),
                            border_radius=12,
                        ),
                    ], alignment="spaceBetween"),
                    ft.Row([
                        ft.Container(
                            content=img_widget,
                            width=90, height=90,
                            bgcolor="#F5F5F5",
                            border_radius=10,
                        ),
                        ft.Column([
                            ft.Text(
                                f"✨ {card['pokemon'].upper()}",
                                weight="bold", size=16, color="#1A237E",
                            ),
                            ft.Text(stars, size=14, color=color),
                            ft.Row([
                                ft.Text(f"❤️ {card['hp']}", size=13, color="#C62828", weight="bold"),
                                ft.Text("  "),
                                ft.Text(f"⚔️ {card['attack']}", size=13, color="#E65100", weight="bold"),
                            ]),
                            ft.Text(
                                f"🎯 {card['similarity']*100:.1f}%",
                                size=11, color="#6A1B9A",
                            ),
                        ], spacing=3, expand=True),
                    ], spacing=10, vertical_alignment="center"),
                ], spacing=8),
                padding=14,
                bgcolor="#FFFFFF",
                border=ft.Border.all(2, color),
                border_radius=16,
                width=340,
            )
        )

    # ── Handlers ──────────────────────────────────────────────────────────────
    async def pick_image(e):
        ruta = seleccionar_archivo()
        if ruta and os.path.exists(ruta):
            img_preview.src = ruta
            img_preview.visible   = True
            img_container.visible = True
            send_btn.disabled = False
            status.value = "✅ Imagen lista — apretá Enviar"
            status.color = "#2E7D32"
        else:
            status.value = "⚠️ Cancelado."
            status.color = "#E65100"
        page.update()

    async def on_send(e):
        if not img_preview.src:
            status.value = "❌ No hay imagen."
            status.color = "#C62828"
            page.update()
            return

        send_btn.disabled = True
        send_btn.text  = "⏳ Procesando..."
        status.value   = "📡 Analizando dibujo con IA..."
        status.color   = "#3949AB"
        result_card.visible = False
        page.update()

        try:
            async with httpx.AsyncClient() as client:
                with open(img_preview.src, "rb") as f:
                    resp = await client.post(
                        f"{SERVER_URL}/upload",
                        files={"file": ("drawing.jpg", f, "image/jpeg")},
                        timeout=40.0
                    )

            if resp.status_code != 200:
                status.value = f"❌ Error del servidor: {resp.status_code}"
                status.color = "#C62828"
                print(f"[ERROR server] {resp.status_code}: {resp.text}")
                return

            data = resp.json()
            result_card.content = build_result_card(data)
            result_card.visible = True
            status.value = f"✅ ¡{data['pokemon'].capitalize()} {'actualizado' if data.get('action')=='actualizada' else 'guardado'} en tu mazo!"
            status.color = "#2E7D32"

        except httpx.ConnectError:
            status.value = "❌ Sin conexión al servidor."
            status.color = "#C62828"
        except Exception as ex:
            status.value = f"❌ Error: {str(ex)[:60]}"
            status.color = "#C62828"
            print(f"[ERROR] {ex}")
        finally:
            send_btn.disabled = False
            send_btn.text = "📤 Enviar al servidor"
        page.update()

    async def show_deck(e):
        deck_area.controls.clear()
        deck_area.visible = True
        btn_hide.visible  = True
        deck_area.controls.append(ft.Text("⏳ Cargando mazo...", color="#9E9E9E", italic=True))
        page.update()

        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{SERVER_URL}/deck", timeout=10.0)
            cards = resp.json().get("cards", [])
            deck_area.controls.clear()

            if not cards:
                deck_area.controls.append(ft.Container(
                    content=ft.Text(
                        "🃏 Tu mazo está vacío\nSubí dibujos para llenarlo",
                        color="#9E9E9E", size=14, text_align="center"
                    ),
                    padding=20, bgcolor="#FFFFFF", border_radius=12, width=320,
                ))
            else:
                deck_area.controls.append(
                    ft.Text(f"✨ Tu Mazo — {len(cards)} carta{'s' if len(cards)!=1 else ''}",
                            weight="bold", size=17, color="#1A237E")
                )
                deck_area.controls.append(ft.Divider(color="#9FA8DA"))
                for i, card in enumerate(reversed(cards)):
                    deck_area.controls.append(
                        build_deck_card(card, i, len(cards))
                    )

        except httpx.ConnectError:
            deck_area.controls.clear()
            deck_area.controls.append(ft.Text("❌ No se pudo conectar.", color="#C62828"))
        except Exception as ex:
            deck_area.controls.clear()
            deck_area.controls.append(ft.Text(f"❌ Error: {str(ex)[:60]}", color="#C62828"))
            print(f"[ERROR deck] {ex}")

        page.update()

    def hide_deck(e):
        deck_area.visible = False
        btn_hide.visible  = False
        page.update()

    # ── Botones ───────────────────────────────────────────────────────────────
    btn_pick = ft.ElevatedButton(
        "📁 Seleccionar imagen", on_click=pick_image,
        bgcolor="#3949AB", color="#FFFFFF", width=280,
    )
    send_btn = ft.ElevatedButton(
        "📤 Enviar al servidor", disabled=True, on_click=on_send,
        bgcolor="#43A047", color="#FFFFFF", width=280,
    )
    btn_deck = ft.ElevatedButton(
        "🃏 Ver Mi Mazo", on_click=show_deck,
        bgcolor="#6A1B9A", color="#FFFFFF", width=280,
    )
    btn_hide = ft.ElevatedButton(
        "❌ Ocultar Mazo", on_click=hide_deck, visible=False,
        bgcolor="#E53935", color="#FFFFFF", width=200,
    )

    # ── Layout ────────────────────────────────────────────────────────────────
    page.add(
        ft.Container(
            content=ft.Column([
                ft.Text("🎨 PokéDraw", size=30, weight="bold", color="#1A237E"),
                ft.Text("Dibujá • Subí • Coleccioná", size=13, color="#7986CB"),
            ], horizontal_alignment="center"),
            padding=ft.Padding.only(bottom=12),
        ),
        ft.Divider(color="#9FA8DA"),
        btn_pick,
        ft.Container(height=8),
        img_container,
        ft.Container(height=8),
        send_btn,
        ft.Container(height=8),
        result_card,
        status,
        ft.Divider(color="#9FA8DA", height=20),
        btn_deck,
        ft.Container(height=4),
        btn_hide,
        deck_area,
        ft.Container(height=12),
        ft.Text(
            "💡 Más similitud = más poder\n⚡ LEGENDARIO  💜 ULTRA RARO  💙 RARO  💚 POCO COMÚN  ⚪ COMÚN",
            size=10, color="#9FA8DA", text_align="center", italic=True,
        ),
    )

if __name__ == "__main__":
    ft.run(main)